## Overview

Classic Motor Market is a private club for European car enthusiasts focused on buying and selling vehicles through a secure, private, members-only platform. The site provides a straightforward, old-school classified listing experience with modern privacy and security features. Think of Bring a trialer but for vintage european cars and not an auction site. Our biggest goal is to keep it private, secure, and prevent tire kickers.

## Site Structure & Navigation

### Header Navigation
- **Logo**: assets/logo.png
- **Main Navigation**:
  - Browse Vehicles
  - Admin Dashboard (Only available if an admin user)
- **Authentication States**:
  - **Not Logged In**: Login, Become a Member, List Your Vehicle
  - **Logged In**: List Your Vehicle, Account dropdown with user info (Admin/Member status), Account Settings, Sign Out

### Footer
- **Logo**: assets/logo.png
- **Brand Section**: Logo, tagline "The premier destination for buying and selling exceptional vehicles. Connect with passionate enthusiasts and find your next adventure."
- **Quick Links**: Browse Vehicles, List Your Vehicle, Become a Member
- **Support**: Contact Us (generate a small page), Terms of Service, Privacy Policy (see privacy-policy.md, terms-of-service.md)
- **Copyright**: © 2025 Classic Motor Market. All rights reserved.

## Page Content & Flows

### 1. Legal Disclaimer (First Visit) see disclaimer.md
**Purpose**: Development version warning, legal protection, and context setting before any site content renders

**Content**:
- **Title**: "Classic Motor Market - Development Version"
- **Warning Icon**: Important Legal Notice
- **Disclaimer Sections**:
  - Development Version Disclaimer
  - Images and Content notice
  - No Commercial Transactions warning
  - Data and Privacy notice
  - Functionality limitations
- **Action**: "I Understand - Enter Development Site" button (must be acknowledged before routing anywhere else; store acceptance in session/local storage or on the user record once logged in)
- **Footer**: Copyright notice

### 2. Home Page
**Purpose**: Main landing page showcasing the platform

**Hero Section**:
- **HeroImage** assets/hero.png
- **Headline**: "Find your next adventure on Classic Motor Market"
- **Subtext**: "Connect with passionate enthusiasts and discover exceptional vehicles. From classic collectibles to modern superautomobiles, your dream ride awaits."
- **CTAs**: "View Listings", "List Your Vehicle"

**Featured Vehicles Section**:
- **Title**: "Featured Vehicles"
- **Subtitle**: "Discover hand-picked exceptional vehicles from our collectors and enthusiasts of enthusiasts"
- **Carousel**: Interactive vehicle showcase with navigation dots
- **Mobile**: Vertical stack of 2 cards with swipe functionality
- **Desktop**: Horizontal carousel showing 3 vehicles
- **CTA**: "View All Vehicles"

**Membership Section**:
- **Title**: "Become a Member"
- **Price**: "$49/year"
- **Benefits**:
  - Direct Contact: "Contact sellers securely via email relay"
  - Early Access: "Preview new showcases 48 hours before the public"
  - VIN Privacy: "View full VINs only as a member"
  - Free Listing: "Your first car listing is included in your membership and only $20 for additional showcases"
  - Garage Access: "Build and share your collection with fellow members"
- **CTA**: "Become a Member"

**About Us Section**:
- **Content**: "Classic Motor Market is a private club for European car enthusiasts who appreciate buying and selling the classic way. Whether you're into timeless classics, stylish daily drivers, or modern sports automobiles, our secure, members-only platform offers a straightforward, old-school classified listing experience—with the privacy you expect."

**Call to Action Section**:
- **Title**: "Ready to join the collectors and enthusiasts?"
- **Subtitle**: "Get access to exclusive showcases, connect with verified sellers, and list your own vehicles with ease."
- **CTAs**: "Join Now", "Browse Vehicles"

### 3. Authentication Flow

#### Login Page
**Content**:
- **Title**: "Sign in to your account"
- **Form Fields**:
  - Email address (required)
  - Password (required, with show/hide toggle)
  - Remember me checkbox
- **Links**: "Forgot your password?", "create a new account"
- **Submit**: "Sign in" / "Signing in..." (loading state)
- **Social Options**: Google, Facebook buttons
- **Redirect**: To listings

#### Signup Page
**Content**:
- **Title**: "Join Classic Motor Market"
- **Member Signup** (Default):
  - **Price**: "$49/annually"
  - **Description**: "Perfect for individual discerning buyers and sellers"
  - **Benefits**: Same 6 benefits as homepage


**Registration Form**:
- Username (required, unique, shown publicly instead of email)
- Email address (required)
- Password (required)
- Confirm Password (required)
- Terms agreement checkbox: "I agree to the Terms of Service and Privacy Policy"
- Membership payment confirmation checkbox (temporary; sets `users.membershipPaymentStatus = 'placeholder_confirmed'` until Stripe Checkout is wired. Without this checked the "Create Account" button stays disabled.)
- **Submit**: "Create Account" / "Creating Account..." (loading state)
- **Redirect**: To listings

### 4. Vehicle Listings & Search

#### Browse Vehicles Page
**Header**:
- **Title**: "Browse Vehicles"
- **View Toggle**: Grid/List view options
- **Results Count**: "X vehicles found"

**Filters Sidebar**:
- **Price Range**: Min/Max inputs
- **Make**: Text input (Type your own)
- **Year**: From/To inputs
- **Condition**: Checkboxes using the new ENUM values (Show car, Driver, It runs, Project)
- **Mileage**: Min Miles/Max Miles inputs
- **Transmission**: Checkboxes (Manual, Automatic, Semi-Automatic, CVT)
- **Clear All Filters** button

**Vehicle Display**:
- **Grid View**: Card layout with image, title, price, location, year, mileage, and the simplified condition grade
- **List View**: Horizontal layout with larger images and descriptions
- **Sold Section**: "Recently Sold" vehicles shown separately with SOLD badges (pulled from `listingStatus = 'sold'`). Sellers can flip listings between Active/Sold in their account, and admins can do the same from the dashboard.
- **Pagination**: Previous/Next with numbered pages

**Loading/Error States**:
- Loading: Spinner with "Loading vehicles..."
- Error: "Error Loading Vehicles" with retry button
- No Results: "No vehicles match your current filters" with clear filters option

#### Vehicle Detail Page
**Hero Image**: Large centered image with SOLD banner if applicable, heart/share buttons

**Basic Info Section**:
- Vehicle title (Year Make Model)
- Price (large, prominent)
- Location, Year, Mileage, Engine, Transmission, Exterior Color, Interior Color & Material (icon row)
- Condition chip using the new labels (Show car / Driver / It runs / Project)

**Vehicle Information**:
- VIN / WMI / Chassis string (full display for members)
- Options & Features narrative (render as formatted paragraph or bulleted summary)
- Modifications narrative (2nd paragraph/card)

**Detailed Sections**:
- **Condition & History**: Card with the selected condition grade, plus the combined "What is the history of the vehicle?" answer
- **Maintenance & Restoration**: Card with the maintenance/restoration text area content
- **Vehicle Story**: Long-form narrative (optional)
- **Title & Documentation**: Listing ID, Title Status (if provided), Carfax availability toggle

**Special Features** (if applicable):
- Homologation Special, Group B Heritage, Production numbers, Final Year Production
- Single Family Owned, Long-Term Florida Car, Right-Hand Drive
- Original Owner Location, Import Year

**Photo Gallery**: Grid of thumbnails that open in lightbox with navigation


**Sidebar**:
- **Seller Info**: Seller name, "Verified Seller" badge
- **Contact**: "Become a Member to Contact Seller" or "Contact Seller" if logged in
- Display the seller's username (never their email) so privacy is preserved

- **Quick Actions**: Save to Watchlist, Share Vehicle, Report Listing

### 5. List Vehicle Flow (see listing-flow.md for field-level detail)

- **Step 1 – Basic Info**: Single-column form that captures Year, Make, Model, VIN/WMI/Chassis, Location, Mileage, Engine, Transmission, Exterior Color, Interior Color & Material, and Asking Price.
- **Step 2 – Options & Features**: Two long-form questions only (options/features narrative and stock vs modifications narrative). All other micro condition prompts were removed.
- **Step 3 – Condition & History**: Radio group for Show car / Driver / It runs / Project plus two text boxes (vehicle history and maintenance/restoration history).
- **Step 4 – Images**: Drag-and-drop uploader with in-place drag handles so sellers can reorder photos before publishing (updates `listing_media.sortOrder`; first item becomes the hero image).
- **Step 5 – Review & Publish**: Read-only preview plus `Save Draft` and `Publish & Pay` CTAs. Publishing requires the temporary "Listing publish fee paid" checkbox that flips `listings.publishFeePaid` to true until the real Stripe flow ships.
#### 6. Admin Dashboard (Admin Only)


**Listings Table**:
- **Columns**: Vehicle (image + details), Listing ID, Price, Seller, Status, Publish Fee Paid?, Created date, Actions
- **Status Badges**: Draft (yellow), Active (green), Sold (red)
- **Quick Actions**: View, Edit, Publish, Toggle Sold, Feature/Unfeature, Delete, Override Publish Fee Paid



#### 7. Account Page
**Sidebar Navigation**:
- My Listings, Watchlist, Membership

**My Listings**:
- List of user's vehicle showcases with status
- Actions: Edit, View, Delete, Toggle Sold/Active, Confirm publish-fee payment (temporary checkbox mirrors admin control)

**Watchlist**:
- Saved vehicles with remove option

**Membership**:
- **Status**: "Member - Active since January 2024"
- **Plan Details**: Classic Motor Market Membership, renews annually at $49, includes first listing publish fee
- **Actions**: Manage Billing, Cancel Membership (no upgrades/downgrades exist)

### 8. User Roles & Permissions

#### Public (Not Logged In)
- View vehicle showcases (active only)
- Browse/search vehicles
- View vehicle details
- Access signup/login
- Cannot contact sellers
- Cannot see full VINs

#### Member (Logged In)
- All public permissions plus:
- Contact sellers directly
- Save vehicles to watchlist
- List vehicles (first listing free)
- Access account dashboard
- View full VINs
- Early access to new showcases (48 hours)
- Mark their own listings as Sold/Active and confirm publish-fee payment status

#### Admin
- All member permissions plus:
- Access Admin Dashboard
- Create/edit/delete any vehicle listing
- Manage user accounts
- View all listing statuses (including drafts)
- Bulk import vehicles
- Feature/unfeature showcases
- Mark vehicles as sold
- Override publish-fee payment state on any listing