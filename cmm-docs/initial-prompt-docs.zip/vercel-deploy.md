# Vercel Deployment Notes

Repo: `atreyusutton/classic-motor-market` (Next.js app in `classic-motor-market/`).

## Project setup (Vercel)
- Root Directory: `classic-motor-market`.
- Build Command: `npm run build` (install: `npm install`; output: `.next`).
- Runtime: Node 18 or 20 (Project Settings → General).
- If Neon schema not applied: run locally from `classic-motor-market/`:  
  `DATABASE_URL=... npx prisma db push`.

## Environment variables (Vercel dashboard)
**Core**
- `DATABASE_URL` – Neon Postgres (include `sslmode=require` if needed).
- `AUTH_SECRET` (or `NEXTAUTH_SECRET`) – strong random string.
- `AUTH_URL` / `NEXTAUTH_URL` – production URL (Vercel/custom domain).
- `AUTH_TRUST_HOST` – `true` (required on Vercel for Auth.js).
- `NEXT_PUBLIC_APP_URL` – same production URL.
- `CLOUDFLARE_ACCOUNT_ID`
- `CLOUDFLARE_API_TOKEN` **or** `CLOUDFLARE_IMAGES_TOKEN`
- `CLOUDFLARE_ACCOUNT_HASH` **or** `NEXT_PUBLIC_CLOUDFLARE_ACCOUNT_HASH` (image delivery hash).
- `STRIPE_SECRET_KEY`
- `RESEND_API_KEY` (optional; without it report flow logs demo output).

**Optional auth providers**
- `AUTH_GOOGLE_ID`, `AUTH_GOOGLE_SECRET`
- `AUTH_FACEBOOK_ID`, `AUTH_FACEBOOK_SECRET`

## Optional: bulk import to Neon
From `classic-motor-market/` with Neon + Cloudflare creds set:
```
DATABASE_URL=... \
CLOUDFLARE_ACCOUNT_ID=... \
CLOUDFLARE_IMAGES_TOKEN=... \
SELLER_EMAIL="seller@example.com" \
npx tsx scripts/import-bulk-vehicles.ts --run --seller-email="$SELLER_EMAIL"
```
- Dry run: omit `--run`.
- Ensure seller exists in Neon first; make admin if desired: `node make-admin.js` with `DATABASE_URL` pointing to Neon.
- Media source: `../bulk-import-vehicles/`, data file `bulk-import-vehicles.txt`.

## Validate deploy
- Pages: `/`, `/listings`, `/login`, `/register`, `/sell`, `/account`, `/admin` (admin user needed).
- Auth: register/login (credentials); social if configured; admin gate blocks non-admin.
- Listings: create/edit/delete; Cloudflare uploads render via `imagedelivery.net`.
- Billing: `/account/billing` and Stripe checkout use `NEXT_PUBLIC_APP_URL` for redirects.
- Reports: sends via Resend if key set; otherwise logs “DEMO MODE” and succeeds.

## Lock down & polish
- After deploy, update `AUTH_URL`/`NEXTAUTH_URL`, `AUTH_TRUST_HOST=true`, and `NEXT_PUBLIC_APP_URL` to the live Vercel domain/custom domain.
- Confirm middleware doesn’t loop; login already redirects to `/` on success.
- Optional: enable Vercel Analytics/Monitoring; add custom domain.

