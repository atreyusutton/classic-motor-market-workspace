Step 1: Basic Information

- Year (required, int between 1900–2100)
- Make (required, free-form string)
- Model (required, free-form string)
- VIN / WMI / Chassis Number (required, string — allow European formats)
- Location (required, free-form string such as "Austin, TX" or "Paris, FR")
- Mileage (required, int)
- Engine (string)
- Transmission (string)
- Exterior Color (required, string)
- Interior Color & Material (string)
- Asking Price (required, int stored in USD cents)

Single-column layout, grouped inputs (no spinner arrows on number inputs).

Step 2: Options, Features, and Modifications

- What options and special features does this vehicle have? (long-form text area)
- Is the vehicle stock or does it have any modifications? (long-form text area)

All legacy "detailed condition" sub-questions are removed per the new plan.

Step 3: Condition & Vehicle History

- Condition (required select, stored as ENUM):
  - Show car
  - Driver
  - It runs
  - Project
- What is the history of the vehicle? (text box combining ownership/story prompts)
- What is known about the maintenance and/or restoration history? (text box)
- Title Status (optional select, stored as ENUM):
  - Clean
  - Salvage
  - Stolen
  - Lien
  - Flood
- Carfax Available (optional boolean checkbox)

Step 4: Images

- Drag & drop upload (max 50 photos, same guidelines as before)
- Drag handle per thumbnail to reorder photos inside the uploader (updates `listing_media.sortOrder`)
- First photo in the sorted list becomes the hero/cover image

Step 5: Review & Publish

- Review card mirrors the final listing layout with the reduced data set
- Actions:
  - `Save Draft`
  - `Publish & Pay` (requires checking "Listing publish fee paid" placeholder toggle which sets `listings.publishFeePaid = true` until the Stripe flow ships)
- If the publish-fee checkbox is unchecked, keep the CTA disabled and surface helper text ("Publishing requires confirming payment. For now, check the box once you've collected the fee manually.")
