Table: listings
-------------------------------------------------
id                      INT PK AUTO_INCREMENT
publicId                VARCHAR UNIQUE
sellerId                INT FK → users.id

listingStatus           ENUM('draft', 'active', 'sold') DEFAULT 'draft'  -- seller dashboard + admin panel can toggle sold flag
publishedAt             TIMESTAMP NULL
featured                BOOLEAN DEFAULT FALSE

publishFeePaid          BOOLEAN DEFAULT FALSE   -- temporary checkbox until Stripe flow lands
publishFeePaidAt        TIMESTAMP NULL
publishFeeMethod        ENUM('placeholder_checkbox', 'stripe') DEFAULT 'placeholder_checkbox'

year                    INT NULL
make                    VARCHAR NULL
model                   VARCHAR NULL
vehicleIdentifier       VARCHAR NULL   -- VIN, WMI, or chassis number
location                VARCHAR NULL   -- free-form City, ST or Country
mileage                 INT NULL
engine                  VARCHAR NULL
transmission            VARCHAR NULL
exteriorColor           VARCHAR NULL
interiorColorMaterial   VARCHAR NULL
askingPrice             INT NULL       -- stored in USD cents

optionsAndFeatures      TEXT NULL      -- Step 2: Options & features text area
modifications           TEXT NULL      -- Step 2: Stock vs modified narrative

conditionGrade          ENUM('show_car', 'driver', 'it_runs', 'project') NULL
vehicleHistory          TEXT NULL      -- Step 3: Ownership & story combined
maintenanceHistory      TEXT NULL      -- Step 3: Maintenance/restoration summary

titleStatus             ENUM('clean', 'salvage', 'stolen', 'lien', 'flood') NULL
carfaxAvailable         BOOLEAN NULL

createdAt               TIMESTAMP DEFAULT NOW()
updatedAt               TIMESTAMP DEFAULT NOW() ON UPDATE NOW()

Table: listing_media
-------------------------------------------------
id              INT PK AUTO_INCREMENT
listingId       INT FK → listings.id (CASCADE DELETE)

type            ENUM('image', 'video')
provider        ENUM('cloudflare_images', 'cloudflare_stream')
providerId      VARCHAR        -- Cloudflare ID

sortOrder       INT            -- 1, 2, 3...
isCover         BOOLEAN DEFAULT FALSE
altText         VARCHAR NULL

createdAt       TIMESTAMP DEFAULT NOW()
updatedAt       TIMESTAMP DEFAULT NOW() ON UPDATE NOW()

Table: saved_listings
-------------------------------------------------
id          INT PK AUTO_INCREMENT
userId      INT FK → users.id (CASCADE DELETE)
listingId   INT FK → listings.id (CASCADE DELETE)
createdAt   TIMESTAMP DEFAULT NOW()

Table: users
-------------------------------------------------
id                      INT PK AUTO_INCREMENT
publicId                VARCHAR UNIQUE DEFAULT uuid()
username                VARCHAR UNIQUE NULL         -- seller handle shown publicly

email                   VARCHAR UNIQUE
passwordHash            VARCHAR NULL
name                    VARCHAR NULL
phone                   VARCHAR NULL
image                   VARCHAR NULL                -- profile image URL
emailVerified           TIMESTAMP NULL

stripeCustomerId        VARCHAR NULL
membershipStatus        ENUM('none', 'member', 'expiredMember') DEFAULT 'none'
membershipPaymentStatus ENUM('unpaid', 'placeholder_confirmed', 'paid') DEFAULT 'unpaid'  -- placeholder_confirmed = manual checkbox during dev
membershipPaidAt        TIMESTAMP NULL
membershipExpiresAt     TIMESTAMP NULL
isAdmin                 BOOLEAN DEFAULT FALSE

createdAt               TIMESTAMP DEFAULT NOW()
updatedAt               TIMESTAMP DEFAULT NOW() ON UPDATE NOW()

-- Relations: listings[], savedListings[], accounts[], sessions[]

Table: accounts (Auth.js standard)
-------------------------------------------------
id                 String  PK DEFAULT uuid()
userId             INT     FK → users.id (CASCADE DELETE)
type               String
provider           String
providerAccountId  String
refresh_token      String?  (Text)
access_token       String?  (Text)
expires_at         Int?
token_type         String?
scope              String?
id_token           String?  (Text)
session_state      String?

(Composite unique constraint on provider + providerAccountId)

Table: sessions (Auth.js standard)
-------------------------------------------------
id           String   PK DEFAULT uuid()
sessionToken String   UNIQUE
userId       INT      FK → users.id (CASCADE DELETE)
expires      DateTime

Table: verification_tokens (Auth.js standard)
-------------------------------------------------
identifier String
token      String   UNIQUE
expires    DateTime

(Composite unique constraint on identifier + token)
