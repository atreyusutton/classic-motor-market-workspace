# STACK.md
Classic Motor Market — Technology Stack

## Frontend + Backend
Next.js (App Router) — TypeScript  
- Single codebase for UI and API routes  
- Server Components for fast rendering  
- API routes handle listings, auth, payments, media, and search  
Hosting: Vercel

## Database
PostgreSQL  
- Relational data for users, listings, media, saved listings, and memberships  
Hosting options: Neon (recommended) or Supabase

Prisma ORM  
- Type-safe queries  
- Schema-first models  
- Clean migrations and fast iteration
- Adapter for Auth.js integration

## Authentication
Auth.js (NextAuth)  
- Email/password (Credentials provider with bcrypt hashing) or OAuth  
- Sessions mapped to the users table  
- user.id used as sellerId for listings

## Transactional Email
Resend (or similar)
- Handles "Contact Seller" email relay
- System sends email to Seller with Buyer's message
- Seller replies directly to Buyer via their email client
- Protects Seller's email address until they choose to reply

## Payments
Stripe  
- Checkout Sessions  
- Annual membership purchase happens during signup (no upgrade path; collect dues up front)
- Listing publish fee collected right before publishing (publish fee checkbox is temporary until Stripe PaymentIntents are wired)
- Customer management  
- Webhooks update membershipStatus and membershipExpiresAt in the database

## Media
Cloudflare Images  
- Image uploads and optimization  
- Store only the Cloudflare imageId in the listing_media table

Cloudflare Stream (optional)  
- For hosting and streaming videos

## UI
Tailwind CSS  
- Utility-first styling  

shadcn/ui  
- Reusable component system for forms, modals, tables, navigation, and layout
- Uses react-hook-form and zod for form validation
- Uses react-dropzone for file uploads

## Optional Extras
Caching: Vercel KV or Upstash Redis  
Monitoring: Sentry