This is my planning document for the future of this site with tweaks updates and everything else. We are about to go through a major visual UI and UX update so I am trying to get the rest of it up to date before that happens.

Current Needed Updates

1. To be clear there are 2 times that a payment will be processed on this site. the first is when a new member signs up. There is no upgrade later the only way to become a member is to pay as you're making your account. For now we can make a placeholder like a check box that will eventually go through a stripe payment. The next way that a payment will go through is when publishing a listing to the site.

2. When a user is added we need a username that is not the email. This is what will be shown to the public as the seller as a big part of our marketing and site is privacy so that will need to be added to the site.

3. Work on SOLD flags. We need to have sold flags added to the listing cards and moved to a sold listings seciton under the current listings, Also Not just on the card in frount of the description they need to be on the actual indivigual page. The flag is already in the db but both the seller in the account listing and the admin on the admin panel page should be able to change the flag.

3. Need to work on the listing flow

New Listing Flow

Step 1: Basic info

- Break up questions into blocks. One column of questions. No up/down arrows needed in input boxes.

- Boxes

- Year
- Make
- Model
- VIN, WMI, or Chasis Number
- Location
- Mileage
- Engine
- Transmission
- Exterior Color
- Interior color & Material
- Asking Price

Step 2: Options, Features, and Modifications

Get rid of almost all of this. Keep:

Options and features:

What options and special features does this vehicle have? - Text box

Is the vehicle stock or does it have any modifications? - Text box

Step 3: Condition and Vehicle history

Condition: Select from: (no numbers) what's the best way to adjust this in the db? Numbers or elum or something else?

"Show car"", "Driver", "It runs", "Project"

What is the history of the vehicle? (Include details such as: How long have you owned it, how many owners, special events it participated in, or personal story.) - Text box

What is known about the maintenance and/or restoration history? (Include details such as: Last oil change, tire condition, address known issues with the vehicle model, and minor or major restoration work.) - Text box

Step 4: Images

Along side what we have now the images need to be able to be reordered while in this upload section.

Step 5: Review 

Remake this review similar to how we have now but with the updated inputs and db pulls from the updates I've outlined above. The listing page needs a publish and pay like I said above this can be a temporary checkbox that changes an is paid in the database and updates it.

4. Add a disclaimer when first visiting the site per /legal-docs/disclaimer.md so people understand if they come across the document.

---

## Implementation Roadmap (Lead Dev Notes)

1. **Database & Prisma**
   - Add `users.username` (unique, public handle), plus `membershipPaymentStatus`, `membershipPaidAt`, and `membershipStatus` default enforcement.  
   - Add `listings.publishFeePaid`, `publishFeePaidAt`, `publishFeeMethod`, switch to `vehicleIdentifier`, `location`, `optionsAndFeatures`, `modifications`, `conditionGrade`, `vehicleHistory`, `maintenanceHistory`; remove legacy condition/detail columns.  
   - Update enums (`conditionGrade`, consolidate listing status toggle logic).  
   - Regenerate Prisma client and create a migration; write data-migration SQL to backfill `vehicleIdentifier` with old VIN data and copy `zipCode → location` until UI ships.

2. **Seed/Data Migration Strategy**
   - Existing users/listings do **not** need to be deleted: run an `UPDATE` to copy current VIN/zip values into the new columns before dropping old ones.  
   - For new NOT NULL fields, set defaults (`conditionGrade = 'driver'`, `publishFeePaid = false`).  
   - Provide a one-time script that rewrites `listings` JSON used in seeds/tests.

3. **Signup & Membership Flow**
   - Update registration form to collect username + membership checkbox, mark `membershipPaymentStatus = 'placeholder_confirmed'` until Stripe checkout integration is ready.  
   - Surface username anywhere seller info is rendered (listing cards/detail/admin).  
   - Block account creation unless both terms + payment placeholder are checked.

4. **Listing Wizard**
   - Rebuild steps to match new flow (Basic Info, Options & Features, Condition & History, Images with drag-to-reorder, Review & Publish).  
   - Replace `zipCode` with free-form `location`, rename VIN input label, drop fuel type & micro condition questions.  
   - Step 5 should include `publishFeePaid` checkbox (temporary) and disable Publish until checked + minimum inputs satisfied.  
   - Ensure `listingStatus` stays `draft` until Publish action runs; once publish triggered, set `publishedAt`, mark `publishFeePaid`.

5. **Seller & Admin Controls**
   - Account → My Listings: add Sold toggle + Publish Fee confirmation action.  
   - Admin dashboard: add column & bulk action for publish fee state; ensure sold flag updates across browse/detail pages.

6. **Public Experience**
   - Browse filters: use new condition chips only, remove fuel-type filtering for now.  
   - Listing detail: reorganize sections to show condensed data + new narratives.  
   - Inject disclaimer modal/page (legal-docs/disclaimer.md) on first visit prior to rendering rest of app (session/local storage gate).









   Add username to account settings

   